#!/usr/bin/env python3
import sys
from math import sqrt

# Initialize the variables to accumulate data
current_col = None
sum_x = 0.0
sum_x2 = 0.0
count = 0

# Process each key-value pair from the mapper file
for line in sys.stdin:
    col, x, x2, cnt = line.strip().split('\t')

    col = int(col)
    x = float(x)
    x2 = float(x2)
    cnt = int(cnt)

    # Processing the same column
    if current_col is None:
        current_col = col

    if current_col != col:
        # Output the statistics for the current column
        mean = sum_x / count
        variance = (sum_x2 / count) - (mean ** 2)
        stddev = sqrt(variance)
        print(f"Column {current_col}: Mean = {mean:.6f}, Variance = {variance:.6f}, StdDev = {stddev:.6f}")

        # Reset accumulators for the next column
        sum_x = 0.0
        sum_x2 = 0.0
        count = 0
        current_col = col

    # Accumulate values
    sum_x += x
    sum_x2 += x2
    count += cnt

# Final column output
if current_col is not None:
    mean = sum_x / count
    variance = (sum_x2 / count) - (mean ** 2)
    stddev = sqrt(variance)
    print(f"Column {current_col}: Mean = {mean:.6f}, Variance = {variance:.6f}, StdDev = {stddev:.6f}")

