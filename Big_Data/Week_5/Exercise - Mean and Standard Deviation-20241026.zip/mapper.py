#!/usr/bin/env python3
import sys

# Skip the header row in the data file
header = True

# Process each line of the input obtained
for line in sys.stdin:
    if header:
        header = False
        continue  # Skip the first line (header)

    values = list(map(float, line.strip().split()))

    if len(values) != 5:
        continue  # Skip any line that doesn't have exactly 5 columns

    # Get intermediate values for each column
    for i in range(5):
        print(f"{i}\t{values[i]}\t{values[i] ** 2}\t1")

